<!DOCTYPE html>
 <html>
    <head>
        <title>Login and Registration Form</title>

        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            
        <?php
            //adding your code here
            if(isset($_POST["emailsignup"]) && isset($_POST["usernamesignup"]) && isset($_POST["passwordsignup"])) {
                echo "THANK YOU FOR REGISTRATION<br>";
                echo "YOUR USERNAME IS <b>".$_POST["usernamesignup"]."</b><br>";
                echo "YOUR EMAIL IS <b>".$_POST["emailsignup"]."</b><br>";
            } else {
                echo 'Please fill the form completely';
            }
        ?>
	</div>
    </body>
</html>
