<?php session_start();

//setting username and password

	ob_start();
	$username = array("admin","user","sale");
	$password = array("123","456","789");

//adding your code here

    $login_status = false;
    
    if(isset($_POST["username"]) && isset($_POST["password"])) {
        if($_POST["username"] == $username[0]) {
            if($_POST["password"] == $password[0]) {
                $login_status = true;
            }
            // goto welcome.php
        }
        else if($_POST["username"] == $username[1]) {
            if($_POST["password"] == $password[1]) {
                $login_status = true;
            }
        }
        else if($_POST["username"] == $username[2]) {
            if($_POST["password"] == $password[2]) {
                $login_status = true;
            }
        }
    }
    
    if($login_status) {
        $_SESSION["logIn"] = true;
        header("Location: welcome.php");
    } 
    else {
        echo '<center>';
        echo 'Wrong username or password!<br>Please go back and re enter them again<br>';
        echo '<a href="index.php"><< <b>BACK<b></a>';
        echo '</center>';
        $_SESSION["errormsg"] = "Wrong Username or Password";
    }

?>

<!DOCTYPE html>
 <html>
    <head>
        <title>Login and Registration Form</title>

        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
            
        <?php
            //adding your code here
        ?>
	</div>
    </body>
</html>
