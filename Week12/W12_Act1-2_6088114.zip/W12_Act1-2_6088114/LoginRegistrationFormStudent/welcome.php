<?php session_start();?>
<!DOCTYPE html>
 <html>
    <head>
        <title>Login and Registration Form</title>

        <link rel="stylesheet" type="text/css" href="css/demo.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
    </head>
    <body>
        <div class="container">
        
        <?php
            //adding your code here
            if(isset($_SESSION["logIn"]) && $_SESSION["logIn"]) {
                echo "<div id=". "wrapper h1" . "> WELCOME TO OUR SYSTEM </div>";
                unset ($_SESSION["logIn"]);
            }
            else {
                echo "PLEASE LOGIN";            
            }
        ?>
            
	</div>
    </body>
</html>
